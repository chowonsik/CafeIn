-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: cafein.cckcnhsswc6w.ap-northeast-2.rds.amazonaws.com    Database: cafein
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `email` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `nickname` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `oauth` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `oauth_id` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=218 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'2021-09-28 19:30:46','co323co@gmail.com','admin',NULL,NULL,'Ba3QoRojELCsmyG6xzy6iQ==','ACTIVATE',NULL),(46,'2021-09-28 11:15:58','ssafy5@naver.com','ssafy5',NULL,NULL,'Ba3QoRojELCsmyG6xzy6iQ==','ACTIVATE','2021-09-28 11:15:58'),(49,'2021-09-28 14:43:41','test@naver.com','test',NULL,NULL,'ONgkvv3qwp2+gagGwk0eQA==','ACTIVATE','2021-09-29 20:12:07'),(113,'2021-10-01 15:24:02','ssafytest@ssafy.com','ssafytest',NULL,NULL,'EimPUad9nxe5um67y+5Yrg==','DELETED','2021-10-05 00:17:02'),(124,'2021-10-02 16:53:15','safy@safy.com','싸피님',NULL,NULL,'7OxvdcmtvMcIe5tYnFu89A==','ACTIVATE','2021-10-07 10:29:03'),(153,'2021-10-04 15:24:25','test@test.com','테스트',NULL,NULL,'QovH0J7RyDTzsCVRREwdDA==','DELETED','2021-10-05 00:05:59'),(155,'2021-10-04 16:05:15','hsj7630@daum.net','dsgdfs',NULL,NULL,'QovH0J7RyDTzsCVRREwdDA==','ACTIVATE','2021-10-04 16:05:15'),(156,'2021-10-04 16:05:37','abc@abc.om','afadf',NULL,NULL,'UiKzLKdvsHW1FWlLQpN7Ig==','ACTIVATE','2021-10-04 16:05:37'),(157,'2021-10-04 16:24:29','hooni@ssafy.com','후니',NULL,NULL,'xoWaNsmsL9rSlMhVz+YSXA==','DELETED','2021-10-05 00:08:51'),(162,'2021-10-04 21:06:30','hanhelsink@gmail.com','사피사피',NULL,NULL,'UoLECw8NjZAYMrhD1pMazA==','ACTIVATE','2021-10-04 21:06:30'),(163,'2021-10-04 21:17:10','abcabc@abcabc.com','adfasdf',NULL,NULL,'rVSv74hOrqeCibYelExQ2g==','DELETED','2021-10-05 00:11:23'),(165,'2021-10-04 21:42:39','hsj7630@naver.com','원식짱짱맨',NULL,NULL,'nOkvOc8aRDsW/d4aZqEGNg==','DELETED','2021-10-05 00:12:56'),(166,'2021-10-04 21:52:28','asjfkladfkl@adjflka.lkjasdf','adf',NULL,NULL,'NVidxIO363I2tluw9FgUTg==','ACTIVATE','2021-10-04 21:52:28'),(168,'2021-10-05 00:15:03','abc@abc.com','abc',NULL,NULL,'rVSv74hOrqeCibYelExQ2g==','DELETED','2021-10-05 00:15:16'),(169,'2021-10-05 00:18:57','aws@aws.com','aws',NULL,NULL,'7Wov72PcEzhmyxzrZ1bZQA==','DELETED','2021-10-05 00:19:07'),(170,'2021-10-05 00:20:37','aws@aws.com','aws',NULL,NULL,'7Wov72PcEzhmyxzrZ1bZQA==','ACTIVATE','2021-10-05 00:20:37'),(171,'2021-10-05 00:21:38','aws1@aws.com','aws11',NULL,NULL,'7Wov72PcEzhmyxzrZ1bZQA==','DELETED','2021-10-05 00:22:12'),(172,'2021-10-05 00:23:16','aws2@aws.com','aws2',NULL,NULL,'7Wov72PcEzhmyxzrZ1bZQA==','DELETED','2021-10-05 00:23:30'),(173,'2021-10-05 09:44:28','t@t.com','뭐냐',NULL,NULL,'rVSv74hOrqeCibYelExQ2g==','ACTIVATE','2021-10-05 10:57:24'),(174,'2021-10-05 10:20:06','zxc@zxc.com','zxv',NULL,NULL,'DqJXtXlvi0Nd44GRH4654g==','DELETED','2021-10-05 10:20:23'),(175,'2021-10-05 10:21:01','zxv@zxv.com','zxv',NULL,NULL,'DqJXtXlvi0Nd44GRH4654g==','DELETED','2021-10-05 10:22:14'),(176,'2021-10-05 10:22:59','zxv@zxv.com','zxc',NULL,NULL,'DqJXtXlvi0Nd44GRH4654g==','ACTIVATE','2021-10-05 10:22:59'),(178,'2021-10-05 10:48:43','123@123.com','조원식짱짱맨',NULL,NULL,'rVSv74hOrqeCibYelExQ2g==','ACTIVATE','2021-10-06 21:29:49'),(179,'2021-10-05 10:48:52','234@234.com','234',NULL,NULL,'f9NhfF+CKXsbWLIhxkMmQg==','ACTIVATE','2021-10-05 10:48:52'),(215,'2021-10-07 00:26:54','co323co2@gmail.com','coco',NULL,NULL,'OUT445l0FscIhkTpT1x9bg==','ACTIVATE','2021-10-07 00:26:54'),(216,'2021-10-07 10:06:49','wlsdhr0831@naver.com','진옥',NULL,NULL,'NQZ+kSbgzfamXYhbR2RqRA==','ACTIVATE','2021-10-07 10:06:49');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-07 11:26:48
